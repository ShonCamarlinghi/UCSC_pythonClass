def multby2(x): 
	return x*2
	
# Returns True if x is even, otherwise returns False
def isEven(x):
	return x%2==0
