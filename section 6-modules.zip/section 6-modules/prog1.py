# Default value
def increment(a,incr=1):
    a = a+incr
    return a